# MASTER ANTIGRAVITY BRAIN IMPLEMENTATION - AUDIT & MIGRATION PLAN

## PHASE 1 — AUDIT RESULTS
**Current State:** 
The repository currently holds an `.agent/` directory (note the singular name) containing:
- `Skills.md` (acting as the router index)
- `architecture.yaml`
- `skills/` (divided into subdirectories like core, engineering, ai, etc., with placeholder `.md` files)
- `agents/` (19 agent `.md` files, covering core orchestrators and specialists)
- `workflows/`, `policies/`, `templates/`, `schemas/`, `logs/`
- **Missing:** A root `AGENTS.md`, a `.agents/rules/` directory, an `mcp/` directory, and the overarching `capabilities` registry.

**Constraint Checklist:**
- Do not delete or merge any skill, agent, or file.
- Optimize and create necessary files.
- Align with Antigravity 2.0 (AGENTS.md + .agents/ + MCP + Artifacts).

---

## PROPOSED MIGRATION PLAN

### Step 1: Directory Standardization (Rename & Scaffold)
- Rename `.agent/` to `.agents/` to natively align with Google Antigravity ecosystem conventions.
- Scaffold missing directories: `.agents/rules/`, `.agents/registry/`, `.agents/skills/_router/`, `mcp/policies/`, and ensure `artifacts/` is formally used for state handoffs.

### Step 2: Layer 1 — Identity (`AGENTS.md`)
- **Action:** Create `AGENTS.md` at the root of the project.
- **Purpose:** Serve as the "Master Brain", defining the system mission, execution lifecycle (Understand → Classify → Route...), and anti-hallucination rules. 

### Step 3: Layer 2 — Rules (`.agents/rules/`)
- **Action:** Create 6 distinct rule files:
  - `00-master-brain.md` (Always-on execution lifecycle)
  - `01-token-economy.md` (Context management)
  - `02-reasoning.md` (Structured internal reasoning)
  - `03-verification.md` (Independent verification mandates)
  - `04-security.md` (Least privilege)
  - `05-project-context.md`

### Step 4: Layer 3 — Skills & Router (`.agents/skills/`)
- **Action 1:** Create `.agents/skills/_router/SKILL.md` (The Master Skill Router, migrating the logic from the old `.agent/Skills.md`).
- **Action 2:** Inject standard YAML frontmatter (name, description) into all existing `.md` files within the `skills/*` subdirectories to make them programmatically discoverable without deleting any existing placeholder content.

### Step 5: Layer 4 — Tools & MCP (`mcp/policies/`)
- **Action:** Create `mcp/policies/` with `research.yaml`, `development.yaml`, `production.yaml`, and `browser.yaml`.
- **Purpose:** Implement the scoped, least-privilege tool access model so that not every agent has unrestricted MCP access.

### Step 6: Layer 5 — Workflows (`.agents/workflows/`)
- **Action:** Create reusable, autonomous pipeline definitions:
  - `/deep-research`
  - `/build`
  - `/debug`
  - `/secure-build`
  - `/ml-pipeline`
  - `/fullcycle` (The master orchestration workflow)

### Step 7: Registry Integration (`.agents/registry/`)
- **Action:** Move the existing `architecture.yaml` and `registry.yaml` into `.agents/registry/`. Create `capabilities.yaml`, `agents.yaml`, `mcp.yaml`, and `workflows.yaml`.
- **Purpose:** Give the Master Router a machine-readable capability map rather than hard-coded references.

---

## REQUEST FOR FINAL APPROVAL
Please review the audit and proposed migration plan above. If you approve, I will automatically execute these steps sequentially, ensuring no data is lost while upgrading the architecture to the highly modular, Antigravity-native setup.
