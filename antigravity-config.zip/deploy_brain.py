import os
import shutil

base_dir = r'g:\My Drive\Skills, MCP and Agentic AI Automation and Optimization'
agents_dir = os.path.join(base_dir, '.agents')
skills_dir = os.path.join(agents_dir, 'skills')

# Step 1: Reorganize skills into skill_name/SKILL.md format
for root, dirs, files in list(os.walk(skills_dir)):
    for file in files:
        if file.endswith('.md') and file != 'SKILL.md':
            path = os.path.join(root, file)
            skill_name = file.replace('.md', '')
            
            # Create a new directory for the skill
            new_skill_dir = os.path.join(skills_dir, skill_name)
            os.makedirs(new_skill_dir, exist_ok=True)
            
            # Move and rename to SKILL.md
            new_path = os.path.join(new_skill_dir, 'SKILL.md')
            shutil.move(path, new_path)
            
# Step 2: Clean up empty category directories
for root, dirs, files in list(os.walk(skills_dir, topdown=False)):
    if not os.listdir(root):
        os.rmdir(root)

# Step 3: Copy to IDE global config
global_config_dir = r'C:\Users\user\.gemini\config'
global_skills_dir = os.path.join(global_config_dir, 'skills')
global_agents_dir = os.path.join(global_config_dir, 'agents')
global_rules_dir = os.path.join(global_config_dir, 'rules')
global_workflows_dir = os.path.join(global_config_dir, 'workflows')

# Function to merge directories without deleting existing files
def merge_dirs(src, dst):
    if not os.path.exists(src): return
    os.makedirs(dst, exist_ok=True)
    for item in os.listdir(src):
        s = os.path.join(src, item)
        d = os.path.join(dst, item)
        if os.path.isdir(s):
            merge_dirs(s, d)
        else:
            shutil.copy2(s, d)

merge_dirs(skills_dir, global_skills_dir)
merge_dirs(os.path.join(agents_dir, 'agents'), global_agents_dir)
merge_dirs(os.path.join(agents_dir, 'workflows'), global_workflows_dir)

# Rules in IDE config are JSON. But maybe AGENTS.md and .agents/rules/ can be copied?
# We will copy AGENTS.md to global config if possible, or just copy the rules directory.
merge_dirs(os.path.join(agents_dir, 'rules'), global_rules_dir)

print("Restructured skills and deployed to IDE Brain globally.")
