# Context Manager Agent

Responsibilities: determine relevant context, remove irrelevant context, maintain task state, prevent duplication.
