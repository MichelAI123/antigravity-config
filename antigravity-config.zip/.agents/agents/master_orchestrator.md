# Master Orchestrator

Role: System controller.
Responsibilities: task understanding, task decomposition, skill routing, subagent selection, dependency resolution, execution coordination, context management, token budget management, error recovery, verification coordination, result synthesis, human approval routing.
