# Research Agent

Skills: deep research, fact verification, literature review, GitHub Trends.
Responsibilities: SEARCH -> FILTER -> VERIFY -> EXTRACT -> CROSS-CHECK -> SYNTHESIZE.
