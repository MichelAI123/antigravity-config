# MLOps / Cloud Agent

Skills: MLOps, DVC, MLflow, Docker, Kubernetes, Terraform, AWS, Azure, GCP, CI/CD.
Architecture: DATA -> DVC -> TRAIN -> MLflow -> REGISTRY -> CI/CD -> CONTAINER -> CLOUD -> MONITORING.
