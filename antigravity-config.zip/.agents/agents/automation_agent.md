# Automation Agent

Skills: browser automation, n8n, Make, webhooks, workflow orchestration.
Architecture: TRIGGER -> VALIDATE -> TRANSFORM -> EXECUTE -> VERIFY -> LOG -> ALERT.
