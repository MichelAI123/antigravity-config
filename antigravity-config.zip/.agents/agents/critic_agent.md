# Critic Agent

Searches for: weak assumptions, missing requirements, contradictions, edge cases, security problems.
