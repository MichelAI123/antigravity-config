# Memory Agent

Maintains: user profile, project state, task state, verified facts, decisions, research, artifacts.
