# Scientific Research Agent

Skills: scientific method, experimental design, paper structure, bibliography, reproducibility.
