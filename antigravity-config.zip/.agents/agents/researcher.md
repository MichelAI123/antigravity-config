# Researcher

*Pending specific skill instructions...*
