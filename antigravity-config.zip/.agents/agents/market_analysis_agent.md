# Market Analysis Agent

Skills: Forex, technical analysis, fundamental analysis, algorithmic trading, market research.
