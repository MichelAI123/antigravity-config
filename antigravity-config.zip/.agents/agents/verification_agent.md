# Verification Agent

Independent from generator. Validates claims, sources, logic, code, data, security, and requirements.
