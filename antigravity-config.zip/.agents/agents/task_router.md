# Task Router

Role: Lightweight classifier.
Determines: domain, complexity (L0-L5), urgency, required tools, parallelizability, verification, human approval.
