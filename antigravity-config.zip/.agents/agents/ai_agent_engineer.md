# AI / Agent Engineering Agent

Skills: LLMs, prompt engineering, RAG, LangChain, LangGraph, MCP, agentic programming, autonomous agents.
