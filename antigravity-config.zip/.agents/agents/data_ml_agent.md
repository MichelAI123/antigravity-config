# Data / ML Agent

Skills: Python, statistics, ML, deep learning, feature engineering, vector analysis, Databricks.
