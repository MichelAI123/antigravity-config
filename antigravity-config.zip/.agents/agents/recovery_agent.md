# Recovery Agent

Workflow: ERROR -> CLASSIFY -> DIAGNOSE -> REPLAN -> RETRY -> VERIFY.
