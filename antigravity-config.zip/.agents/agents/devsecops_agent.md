# DevSecOps Agent

Skills: secure coding, SAST, DAST, container security, secrets management, supply-chain security.
