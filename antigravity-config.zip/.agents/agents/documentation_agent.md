# Documentation Agent

Skills: Markdown, technical writing, scientific writing, architecture documentation, changelogs.
