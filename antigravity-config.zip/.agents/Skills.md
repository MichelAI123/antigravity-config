# Skills Registry & Router

## Purpose

This file is the central index and routing layer for the agent's
specialized capabilities.

Do NOT load every skill for every task.
Use progressive skill loading and a multi-agent orchestrated architecture.

---

# Execution Pipeline (Multi-Agent Architecture)

User Task
→ Master Orchestrator (Task understanding, context, delegation)
→ Task Router (Complexity & skill classification)
→ Planner / Router (Decomposition, dependency analysis)
→ Minimum Required Skills & Agents (Specialist subagents)
→ Execution (Parallel or sequential based on dependencies)
→ Verifier / Critic (Independent quality check)
→ Synthesizer / Final Response (Or recovery/replanning if failed)

---

# Architecture & Configuration

Refer to [architecture.yaml](file:///g:/My%20Drive/Skills,%20MCP%20and%20Agentic%20AI%20Automation%20and%20Optimization/.agent/architecture.yaml) for the full configuration.

## Core Agents

| Agent | Path | Role |
|---|---|---|
| Master Orchestrator | agents/master_orchestrator.md | System controller, coordinates execution |
| Task Router | agents/task_router.md | Lightweight classifier (domain, complexity) |
| Planning Agent | agents/planning_agent.md | Transforms tasks into subtasks & dependencies |
| Context Manager | agents/context_manager.md | Maintains state, filters irrelevant context |
| Memory Agent | agents/memory_agent.md | Maintains verified facts, project state, decisions |
| Verification Agent | agents/verification_agent.md | Independent quality gate (code, logic, source) |
| Critic Agent | agents/critic_agent.md | Identifies assumptions, edge cases, vulnerabilities |
| Recovery Agent | agents/recovery_agent.md | Replans and retries failed operations |

## Specialist Agents

| Agent | Path |
|---|---|
| Research Agent | agents/research_agent.md |
| Scientific Research Agent | agents/scientific_research_agent.md |
| Software Engineering Agent| agents/software_engineering_agent.md |
| AI / Agent Engineer | agents/ai_agent_engineer.md |
| Data / ML Agent | agents/data_ml_agent.md |
| MLOps / Cloud Agent | agents/mlops_cloud_agent.md |
| DevSecOps Agent | agents/devsecops_agent.md |
| Automation Agent | agents/automation_agent.md |
| Market Analysis Agent | agents/market_analysis_agent.md |
| Career / ATS Agent | agents/career_agent.md |
| Documentation Agent | agents/documentation_agent.md |

---

# Progressive Loading Rules

Before loading a skill or invoking an agent, ask:

1. Is this skill directly required?
2. Is it a dependency?
3. Does it materially improve correctness?
4. Is there already a loaded skill providing this capability?

If the answer is NO to all four:
DO NOT LOAD IT.

---

# Verification & Independence

- **Independent Verification**: The Verification Agent MUST be independent from the generator agent. A generator cannot verify its own work.
- **Parallel Execution**: Only parallelize independent tasks (e.g., disjoint research). Dependent tasks (Architecture -> Implementation -> Testing) MUST remain sequential.
- **Async Execution**: Long-running subtasks should run asynchronously in the background.

---

# Never

Never:
- fabricate facts or citations
- bypass security controls or expose credentials
- execute destructive operations without authorization
- load unnecessary skills or invoke unnecessary agents
- claim verification that did not occur
- give an agent unrestricted tool access (scope tools strictly to the agent's domain)
