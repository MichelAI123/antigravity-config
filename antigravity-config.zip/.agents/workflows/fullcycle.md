/fullcycle <task>
1. Understand task
2. Classify task
3. Select minimum skills
4. Select agents
5. Select tools
6. Create execution plan
7. Execute tasks (parallel/sequential)
8. Critic review
9. Independent verification
10. Recovery if failed
11. Synthesize
12. Quality gate
13. Result