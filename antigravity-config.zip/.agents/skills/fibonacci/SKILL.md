---
name: fibonacci
description: Specialized instructions and capabilities for fibonacci
---

# Fibonacci

*Pending specific skill instructions...*
