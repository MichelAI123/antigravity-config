---
name: quantitative-analysis
description: Specialized instructions and capabilities for quantitative-analysis
---

# Quantitative Analysis

*Pending specific skill instructions...*
