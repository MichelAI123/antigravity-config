---
name: debugging
description: Specialized instructions and capabilities for debugging
---

# Debugging

*Pending specific skill instructions...*
