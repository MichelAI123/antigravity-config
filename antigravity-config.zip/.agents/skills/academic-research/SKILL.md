---
name: academic-research
description: Specialized instructions and capabilities for academic-research
---

# Academic Research

*Pending specific skill instructions...*
