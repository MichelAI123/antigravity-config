---
name: observability
description: Specialized instructions and capabilities for observability
---

# Observability

*Pending specific skill instructions...*
