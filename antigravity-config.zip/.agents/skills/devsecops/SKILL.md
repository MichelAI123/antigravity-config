---
name: devsecops
description: Specialized instructions and capabilities for devsecops
---

# Devsecops

*Pending specific skill instructions...*
