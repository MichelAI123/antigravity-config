---
name: market-research
description: Specialized instructions and capabilities for market-research
---

# Market Research

*Pending specific skill instructions...*
