---
name: git
description: Specialized instructions and capabilities for git
---

# Git

*Pending specific skill instructions...*
