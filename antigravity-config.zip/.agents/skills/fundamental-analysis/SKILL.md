---
name: fundamental-analysis
description: Specialized instructions and capabilities for fundamental-analysis
---

# Fundamental Analysis

*Pending specific skill instructions...*
