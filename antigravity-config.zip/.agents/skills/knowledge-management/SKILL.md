---
name: knowledge-management
description: Specialized instructions and capabilities for knowledge-management
---

# Knowledge Management

*Pending specific skill instructions...*
