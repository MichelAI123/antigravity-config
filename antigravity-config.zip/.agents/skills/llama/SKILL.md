---
name: llama
description: Specialized instructions and capabilities for llama
---

# Llama

*Pending specific skill instructions...*
