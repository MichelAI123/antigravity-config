---
name: technical-analysis
description: Specialized instructions and capabilities for technical-analysis
---

# Technical Analysis

*Pending specific skill instructions...*
