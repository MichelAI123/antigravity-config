---
name: verification
description: Specialized instructions and capabilities for verification
---

# Verification

*Pending specific skill instructions...*
