---
name: active-research
description: Specialized instructions and capabilities for active-research
---

# Active Research

*Pending specific skill instructions...*
