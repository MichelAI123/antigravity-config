---
name: active-search
description: Specialized instructions and capabilities for active-search
---

# Active Search

*Pending specific skill instructions...*
