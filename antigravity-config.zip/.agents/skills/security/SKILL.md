---
name: security
description: Specialized instructions and capabilities for security
---

# Security

*Pending specific skill instructions...*
