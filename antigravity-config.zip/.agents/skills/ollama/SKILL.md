---
name: ollama
description: Specialized instructions and capabilities for ollama
---

# Ollama

*Pending specific skill instructions...*
