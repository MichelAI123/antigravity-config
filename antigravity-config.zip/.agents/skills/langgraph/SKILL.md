---
name: langgraph
description: Specialized instructions and capabilities for langgraph
---

# Skill: LangGraph Engineering

## ID

ai.langgraph

## Purpose

Build, debug, evaluate and maintain LangGraph-based agent workflows.

## Trigger Conditions

Load when the task involves:

- LangGraph
- state graphs
- agent orchestration
- graph-based workflows
- durable agent execution

## Dependencies

- core.reasoning
- core.error-handling
- core.verification
- ai.agentic-programming

## Inputs

- requirements
- architecture
- existing code
- LangGraph version
- available tools

## Capabilities

- graph design
- state management
- routing
- checkpoints
- persistence
- human-in-the-loop
- retries
- sub-agents
- evaluation

## Tools

Use only tools required by the task.

## Verification

Verify:

- graph structure
- state transitions
- error handling
- persistence
- tool calls
- tests
- current API compatibility

## Security

Never expose credentials or unrestricted tool access.

## Failure Modes

- invalid graph
- state mismatch
- tool failure
- persistence failure
- API incompatibility

## Output

Return:

- implementation
- architecture
- tests
- verification result
- limitations

## Version Policy

Verify current official documentation before relying on
version-sensitive APIs.
