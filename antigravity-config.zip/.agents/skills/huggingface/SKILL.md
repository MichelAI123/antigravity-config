---
name: huggingface
description: Specialized instructions and capabilities for huggingface
---

# Huggingface

*Pending specific skill instructions...*
