---
name: marketing
description: Specialized instructions and capabilities for marketing
---

# Marketing

*Pending specific skill instructions...*
