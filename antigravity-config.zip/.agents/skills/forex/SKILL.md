---
name: forex
description: Specialized instructions and capabilities for forex
---

# Forex

*Pending specific skill instructions...*
