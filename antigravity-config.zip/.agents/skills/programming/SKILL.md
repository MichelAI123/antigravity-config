---
name: programming
description: Specialized instructions and capabilities for programming
---

# Programming

*Pending specific skill instructions...*
