---
name: github-trends
description: Specialized instructions and capabilities for github-trends
---

# Github Trends

*Pending specific skill instructions...*
