---
name: error-handling
description: Specialized instructions and capabilities for error-handling
---

# Error Handling

*Pending specific skill instructions...*
