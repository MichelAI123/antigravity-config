---
name: browser-automation
description: Specialized instructions and capabilities for browser-automation
---

# Browser Automation

*Pending specific skill instructions...*
