---
name: n8n
description: Specialized instructions and capabilities for n8n
---

# N8N

*Pending specific skill instructions...*
