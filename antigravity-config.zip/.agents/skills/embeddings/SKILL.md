---
name: embeddings
description: Specialized instructions and capabilities for embeddings
---

# Embeddings

*Pending specific skill instructions...*
