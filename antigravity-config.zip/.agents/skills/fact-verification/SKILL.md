---
name: fact-verification
description: Specialized instructions and capabilities for fact-verification
---

# Fact Verification

*Pending specific skill instructions...*
