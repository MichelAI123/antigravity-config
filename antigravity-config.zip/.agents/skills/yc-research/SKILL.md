---
name: yc-research
description: Specialized instructions and capabilities for yc-research
---

# Yc Research

*Pending specific skill instructions...*
