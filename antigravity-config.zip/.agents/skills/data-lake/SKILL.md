---
name: data-lake
description: Specialized instructions and capabilities for data-lake
---

# Data Lake

*Pending specific skill instructions...*
