---
name: citation-management
description: Specialized instructions and capabilities for citation-management
---

# Citation Management

*Pending specific skill instructions...*
