---
name: frontend
description: Specialized instructions and capabilities for frontend
---

# Frontend

*Pending specific skill instructions...*
