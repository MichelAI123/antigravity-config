---
name: sql
description: Specialized instructions and capabilities for sql
---

# Sql

*Pending specific skill instructions...*
