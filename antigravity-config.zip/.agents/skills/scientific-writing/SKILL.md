---
name: scientific-writing
description: Specialized instructions and capabilities for scientific-writing
---

# Scientific Writing

*Pending specific skill instructions...*
