---
name: architecture
description: Specialized instructions and capabilities for architecture
---

# Architecture

*Pending specific skill instructions...*
