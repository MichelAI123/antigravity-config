---
name: structured-logging
description: Specialized instructions and capabilities for structured-logging
---

# Structured Logging

*Pending specific skill instructions...*
