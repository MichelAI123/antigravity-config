---
name: databricks
description: Specialized instructions and capabilities for databricks
---

# Databricks

*Pending specific skill instructions...*
