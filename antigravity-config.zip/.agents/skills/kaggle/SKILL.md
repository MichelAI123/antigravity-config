---
name: kaggle
description: Specialized instructions and capabilities for kaggle
---

# Kaggle

*Pending specific skill instructions...*
