---
name: meta-ads
description: Specialized instructions and capabilities for meta-ads
---

# Meta Ads

*Pending specific skill instructions...*
