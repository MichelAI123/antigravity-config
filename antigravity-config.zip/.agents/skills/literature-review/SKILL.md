---
name: literature-review
description: Specialized instructions and capabilities for literature-review
---

# Literature Review

*Pending specific skill instructions...*
