---
name: backtesting
description: Specialized instructions and capabilities for backtesting
---

# Backtesting

*Pending specific skill instructions...*
