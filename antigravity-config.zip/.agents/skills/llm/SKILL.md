---
name: llm
description: Specialized instructions and capabilities for llm
---

# Llm

*Pending specific skill instructions...*
