---
name: kubernetes
description: Specialized instructions and capabilities for kubernetes
---

# Kubernetes

*Pending specific skill instructions...*
