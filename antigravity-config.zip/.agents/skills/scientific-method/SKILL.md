---
name: scientific-method
description: Specialized instructions and capabilities for scientific-method
---

# Scientific Method

*Pending specific skill instructions...*
