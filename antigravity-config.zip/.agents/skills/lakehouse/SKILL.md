---
name: lakehouse
description: Specialized instructions and capabilities for lakehouse
---

# Lakehouse

*Pending specific skill instructions...*
