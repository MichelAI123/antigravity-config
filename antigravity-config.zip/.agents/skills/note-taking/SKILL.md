---
name: note-taking
description: Specialized instructions and capabilities for note-taking
---

# Note Taking

*Pending specific skill instructions...*
