---
name: reasoning
description: Specialized instructions and capabilities for reasoning
---

# Reasoning

*Pending specific skill instructions...*
