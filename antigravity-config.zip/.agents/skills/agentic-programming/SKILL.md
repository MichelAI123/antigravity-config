---
name: agentic-programming
description: Specialized instructions and capabilities for agentic-programming
---

# Agentic Programming

*Pending specific skill instructions...*
