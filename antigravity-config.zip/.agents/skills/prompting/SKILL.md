---
name: prompting
description: Specialized instructions and capabilities for prompting
---

# Prompting

*Pending specific skill instructions...*
