---
name: deep-research
description: Specialized instructions and capabilities for deep-research
---

# Deep Research

*Pending specific skill instructions...*
