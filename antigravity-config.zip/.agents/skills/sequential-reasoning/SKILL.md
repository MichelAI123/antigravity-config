---
name: sequential-reasoning
description: Specialized instructions and capabilities for sequential-reasoning
---

# Sequential Reasoning

*Pending specific skill instructions...*
