---
name: logical-analysis
description: Specialized instructions and capabilities for logical-analysis
---

# Logical Analysis

*Pending specific skill instructions...*
