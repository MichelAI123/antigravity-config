---
name: pricing-analysis
description: Specialized instructions and capabilities for pricing-analysis
---

# Pricing Analysis

*Pending specific skill instructions...*
