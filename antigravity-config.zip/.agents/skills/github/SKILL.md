---
name: github
description: Specialized instructions and capabilities for github
---

# Github

*Pending specific skill instructions...*
