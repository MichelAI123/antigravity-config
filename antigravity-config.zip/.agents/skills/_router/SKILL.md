---
name: master-skill-router
description: Select the minimum set of specialized skills required to solve the current task.
---

# MASTER SKILL ROUTER
## Step 1 — Classify
Determine domain, objective, complexity, outputs, tool/verification requirements.
## Step 2 — Select Skills
Map the task to the smallest sufficient set of skills (e.g. AI, Research, Automation).
## Step 3 — Remove Unnecessary Skills
Never activate a skill merely because it exists.
## Step 4 — Identify Dependencies
Resolve necessary prerequisites (e.g., LangGraph requires Python and Agentic Programming).
## Step 5 — Select Tools
Choose only tools required by the selected skills.
## Step 6 — Verification
Select the appropriate independent verifier.
