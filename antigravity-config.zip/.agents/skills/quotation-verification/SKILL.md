---
name: quotation-verification
description: Specialized instructions and capabilities for quotation-verification
---

# Quotation Verification

*Pending specific skill instructions...*
