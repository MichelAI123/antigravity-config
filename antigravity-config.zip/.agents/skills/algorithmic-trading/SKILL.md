---
name: algorithmic-trading
description: Specialized instructions and capabilities for algorithmic-trading
---

# Algorithmic Trading

*Pending specific skill instructions...*
