---
name: hallucination-prevention
description: Specialized instructions and capabilities for hallucination-prevention
---

# Hallucination Prevention

*Pending specific skill instructions...*
