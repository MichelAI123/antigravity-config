# Antigravity Master Brain Configuration

Welcome to the **Antigravity Master Brain**, a state-of-the-art, multi-agent architecture and configuration layer for [Google Antigravity](https://antigravity.google/docs).

This repository contains a fully modular, hallucination-resistant, and token-efficient AI engineering system designed to extend Antigravity's capabilities. It transforms the standard AI assistant into a highly reliable autonomous engineering, research, and automation team.

## 🧠 Architecture Overview

The system operates on a progressive skill-loading architecture designed to minimize token usage and maximize context relevance:

- **`AGENTS.md` (Layer 1 - Identity):** The core operating system and execution pipeline (`Understand → Classify → Route → Plan → Execute`).
- **`.agents/rules/` (Layer 2 - Rules):** Global behavioral constraints enforcing structured reasoning, strict verification, security, and the token economy.
- **`.agents/skills/` (Layer 3 - Capabilities):** Modular, domain-specific skills (e.g., Data Science, Web Dev, DevOps) loaded dynamically by the `_router/SKILL.md` only when a task requires them.
- **`mcp/policies/` (Layer 4 - Security):** Least-privilege configurations for Model Context Protocol (MCP) tools, ensuring agents only have access to the tools they absolutely need.
- **`.agents/workflows/` (Layer 5 - Pipelines):** Reusable, autonomous pipelines (e.g., `/fullcycle`, `/deep-research`) triggered via slash commands.
- **`.agents/registry/` (Layer 6 - Orchestration):** Machine-readable capabilities maps that allow the Master Orchestrator to spin up specialized sub-agents.

## 🚀 Installation & Usage

You can use this configuration either project-locally or globally across your entire machine.

### Option A: Workspace/Project Level (Recommended)
To use this brain for a specific project:
1. Clone or download this repository.
2. Copy the `.agents/` folder and `AGENTS.md` into the root of your target project.
3. Open the project in the **Antigravity IDE** or run the **Antigravity CLI** (`agy`). The system will automatically detect and load the local workspace rules.

### Option B: Global Machine Level (IDE Brain)
To make these skills, workflows, and agents available to *every* project you open on your machine:
1. Locate your global Antigravity configuration directory (typically `~/.gemini/config/` on Mac/Linux or `C:\Users\<User>\.gemini\config\` on Windows).
2. Copy the contents of the `.agents/` folder directly into the global config folder (merging with existing `skills/`, `rules/`, `workflows/`, etc.).
3. Copy `AGENTS.md` and `mcp_config.json` to the root of the global config directory.

## 🛡️ Core Principles

By adopting this configuration, your Antigravity environment adheres to these fundamental laws:
1. **No Hallucinations:** Claims requiring evidence must be supported by primary sources.
2. **Progressive Disclosure:** Skills are not blindly dumped into the context window. They are routed and loaded on-demand.
3. **Independent Verification:** Technical changes, factual research, and production code require mandatory independent testing and verification before being synthesized.
4. **Least Privilege:** Destructive external actions are blocked without explicit authorization.

## 🤝 Contributing
Feel free to fork this repository, add your own specialized `SKILL.md` modules, or refine the autonomous workflows to suit your organization's needs!
